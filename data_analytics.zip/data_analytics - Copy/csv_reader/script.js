let graphDuration = 30;
let updateFrequency = 5;

let contents = "";
let contentString = "";
let recent = [];
let header = [];

setInterval(update, 1000/updateFrequency);
//update();

let graphs = [];
function createGraph(type) {
    let graph = document.createElement('div');
    let canvas = document.createElement('canvas');
    canvas.style.backgroundColor = 'lightgray';
    document.body.appendChild(graph);
    graph.appendChild(canvas);
    graphs.push([type, canvas]);
}
createGraph('V');
createGraph('Sec');


// retrieve the CSV data at regular intervals
function getData(){
    $.get("../ev_data/temp.csv", function(data) {
        contentString = data;
    });
}

let cache = [];

// in seconds at updateFrequency rows per second
let cacheSize = 60;
let lastRow = "";

function update(){
    getData();
    let contents = contentString;
    let graphSize = graphDuration * updateFrequency;

    // split away the first line of the CSV file for column names
    contents = contents.split("\n");
    header = contents[0].split(",");

    // remove header line so it doesn't affect the graph
    // and last line because it is always empty
    contents.shift();
    contents.pop();

    for (let i = contents.length - 1; i > 0; i--){
        if(contents[i] != lastRow){
            cache.push(contents[i]);
            if(cache.length > cacheSize * updateFrequency){
               cache.shift();
            }
        }else{
            break;
        }
    }
    lastRow = contents[contents.length - 1];

    // get only the last graphDuration seconds or less of the data
    if(cache.length > graphSize){
        recent = cache.slice(-graphSize);
    }else{
        recent = structuredClone(cache);
    }

    for(let i = 0, l = recent.length; i < l; i++){
        recent[i] = recent[i].split(",");
    }

    // need any graphs?
    for(let i = 0, l = graphs.length; i < l; i++){
        for (let j = 0, jl = header.length; j < jl; j++){
            if(graphs[i][0] != header[j]) {continue;}
            let canvas = graphs[i][1];
            let width = canvas.width;
            let height = canvas.height;
            let interval = width / graphSize;
            let progress = 0;

            let ctx = canvas.getContext("2d");
            ctx.clearRect(0, 0, width, height);
            ctx.beginPath();

            // TODO: custom min and max, styles
            // Cut off first seconds or so of graph for clean scroll
            let filtered = [];
            for (let k = 0, kl = recent.length; k < kl; k++){
                filtered.push(parseFloat(recent[k][j]));
            }

            let min = Math.min.apply(Math, filtered);
            let max = Math.max.apply(Math, filtered);
            let range = max - min;
            let ratio = height / 2 / range;
            let adjustedMin = (min * ratio) - height / 4;

            for (let k = 0, kl = recent.length; k < kl; k++){
                if(k == 0){
                    ctx.moveTo(progress, height - (recent[k][j] * ratio) + adjustedMin);
                }else{
                    ctx.lineTo(progress, height - (recent[k][j] * ratio) + adjustedMin);
                }
                progress += interval;
            }
            ctx.stroke();
        }
    }
}
